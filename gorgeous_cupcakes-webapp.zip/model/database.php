<?php
// database connection details
$host = 'cfmysqldb.cy4crvo1rkrw.us-east-1.rds.amazonaws.com';
$user = 'admin';
$password = 'Password123';
$database = 'gorgeous_cupcakes';
$charset = 'utf8';

try {
    $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
    $conn = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Optional: Remove or update this line if needed.
    $conn->exec("SET NAMES '$charset'");
} catch(PDOException $e) {
    $error_message = $e->getMessage();
    include('../view/database_error.php');
    exit();
}
?>

