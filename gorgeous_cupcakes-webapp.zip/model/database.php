<?php
require 'vendor/autoload.php';

use Aws\SecretsManager\SecretsManagerClient;
use Aws\Exception\AwsException;

// The secret name you stored in Secrets Manager
$secretName = 'cfmysqldb-credentials'; // Replace with your secret name
$region = 'us-east-1'; // Replace with your region

// Create a SecretsManagerClient
$client = new SecretsManagerClient([
    'region' => $region,
    'version' => 'latest',
]);

// Fetch the secret from Secrets Manager
try {
    $result = $client->getSecretValue([
        'SecretId' => $secretName,
    ]);

    if (isset($result['SecretString'])) {
        // Decode the JSON string into an associative array
        $secret = json_decode($result['SecretString'], true);

        // Retrieve the credentials
        $host = $secret['host'];
        $user = $secret['username'];
        $password = $secret['password'];
        $database = 'gorgeous_cupcakes'; // Database name (can be part of the secret or fixed)
    } else {
        // Handle binary secrets if necessary
        $secret = base64_decode($result['SecretBinary']);
    }
} catch (AwsException $e) {
    // Output error message if unable to retrieve secret
    echo "Error retrieving secret: " . $e->getMessage();
    exit();
}

// Connect to the database using the credentials
try {
    $dsn = "mysql:host=$host;dbname=$database;charset=utf8mb4";
    $conn = new PDO($dsn, $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Database connection successful!";
} catch (PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    exit();
}
?>
