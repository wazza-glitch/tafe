<?php
// database connection details
$host = 'cfmysqldb.cy4crvo1rkrw.us-east-1.rds.amazonaws.com';
$user = 'admin';
$password = 'Password123';
$database = 'gorgeous_cupcakes';
$charset = 'utf8mb4';

try {
    $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
    $conn = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Force the connection to use utf8mb4
    $conn->exec("SET NAMES '$charset'");
} catch(PDOException $e) {
    $error_message = $e->getMessage();
    include('../view/database_error.php');
    exit();
}
?>