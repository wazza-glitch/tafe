<?php
	// Database connection details for AWS RDS MySQL instance using environment variables
    $host = getenv('DB_HOST');  // Host (RDS endpoint)
    $user = getenv('DB_USER');  // Username
    $password = getenv('DB_PASSWORD');  // Password
    $database = getenv('DB_NAME');  // Database name
	
	// Connect to database with a try/catch statement
	// If the connection is not successful, display the error message via database_error.php
	// The PDOException class represents the error raised by PDO
	// The PDO error is stored in the variable $e
	// The PDO error is returned as a string via the getMessage() function
	try
	{
		// Set the DSN (Data Source Name) including the character set
		$dsn = "mysql:host=$host;dbname=$database;charset=utf8mb4";
		// Create the PDO connection with the DSN, username, and password
		$conn = new PDO($dsn, $user, $password, [
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Set error mode to Exception
		]);
	}
	catch(PDOException $e)
	{
		// If there's a PDO exception, store the error message and display it
		$error_message = $e->getMessage();
		include('../view/database_error.php');
		exit();
	}
?>
