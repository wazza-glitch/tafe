<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Connection Error</title>  
</head>

<body>
	<h1>Database Connection Error</h1>
	<p>There was an error connecting to the database.</p>
	<!-- display the error message -->
	<p>Error message: <?php echo $error_message; 
	echo "DB_HOST: " . getenv('DB_HOST') . "<br>";
	echo "DB_USER: " . getenv('DB_USER') . "<br>";
	echo "DB_PASSWORD: " . getenv('DB_PASSWORD') . "<br>";
	echo "DB_NAME: " . getenv('DB_NAME') . "<br>";
	
	?></p>
	
</body>
</html>